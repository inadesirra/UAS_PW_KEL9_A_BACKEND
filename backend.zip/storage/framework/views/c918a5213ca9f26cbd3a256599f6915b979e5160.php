<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <p>wellcome <?php echo e($detail['name']); ?></p>
    <h3>please active your account : <?php echo e(url('user/activation', $detail['token'])); ?></h3>
</body>

</html>
<?php /**PATH C:\xampp 7.4\htdocs\UAs\backend\resources\views/Mail.blade.php ENDPATH**/ ?>